PREJONET FARMERS ACADEMY WEBSITE

Files:
- index.html: main website
- style.css: responsive design
- script.js: menu and WhatsApp registration form
- images/: supplied academy photos

HOW TO USE:
1. Keep index.html, style.css, script.js and the images folder together.
2. Open index.html in a browser to preview the site.
3. Upload the entire folder to your web host.
4. The registration form opens WhatsApp to 082 687 0988 with the applicant's details.

NOTE:
The qualification names, SAQA IDs, course details, contact details and fees on the site were entered from the information supplied for the academy. Confirm accreditation/qualification wording and current course pricing before publishing publicly.
